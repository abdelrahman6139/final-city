export declare class AppService {
    getHello(): string;
}
