export declare class StockModule {
}
