City Tools Server - Installation Package
=========================================

Version: 0.0.1

SYSTEM REQUIREMENTS:
- Windows 10/11
- Node.js 20 or higher
- PostgreSQL 15 or higher
- 4GB RAM minimum

INSTALLATION STEPS:
1. Install Node.js from: https://nodejs.org
2. Install PostgreSQL from: https://www.postgresql.org/download/windows/
3. Right-click INSTALL.bat and select "Run as Administrator"
4. Follow the on-screen instructions

SUPPORT:
For support and documentation, contact your system administrator.

