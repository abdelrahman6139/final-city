export declare class CustomersModule {
}
