import "dotenv/config";
declare const _default: import("@prisma/config").PrismaConfigInternal;
export default _default;
