export declare class PurchasingModule {
}
